"""Install the private gateway for the signed desktop app's current user."""
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys
import time

runtime = Path(__file__).resolve().parent
state = Path.home() / ".vibe-terminal-desktop"
state.mkdir(mode=0o700, exist_ok=True)
subprocess.run([sys.executable, "-m", "venv", str(runtime / ".venv")], check=True)
python = str(runtime / ".venv/bin/python")
subprocess.run([python, "-m", "pip", "install", "-r", str(runtime / "requirements.txt")], check=True)
# Use the same Tailscale validation as discovery; bind only to the local tailnet IP.
sys.path.insert(0, str(runtime))
# aiohttp is only installed in the venv, so obtain status with that interpreter.
status = json.loads(subprocess.check_output([python, "-c", "import asyncio,json;from discovery import read_status;print(json.dumps(asyncio.run(read_status())))"], cwd=runtime))
address = next((ip for ip in status.get("TailscaleIPs", status.get("Self", {}).get("TailscaleIPs", [])) if ip.startswith("100.")), None)
if not address:
    raise SystemExit("Connect Tailscale on this Mac, then try again.")
name = subprocess.check_output(["/usr/sbin/scutil", "--get", "ComputerName"], text=True).strip()
configuration = {"endpoint": f"http://{address}:9843", "name": name}
(state / "connection.json").write_text(json.dumps(configuration))
label = "com.thomasguntenaar.vibe-terminal-desktop"
plist_path = Path.home() / "Library/LaunchAgents" / (label + ".plist")
plist_path.parent.mkdir(parents=True, exist_ok=True)
plist = dict(Label=label, ProgramArguments=[python, str(runtime / "server.py"), "--bind", address, "--state", str(state)],
             WorkingDirectory=str(Path.home()), RunAtLoad=True, KeepAlive=True, ThrottleInterval=10,
             EnvironmentVariables={"PATH": str(Path.home()/".local/bin")+":/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin", "USER": os.environ.get("USER", ""), "VIBE_MACHINE_NAME": name},
             StandardOutPath=str(state/"gateway.log"), StandardErrorPath=str(state/"gateway-error.log"))
plist_path.write_bytes(plistlib.dumps(plist))
service = f"gui/{os.getuid()}/{label}"
subprocess.run(["launchctl", "bootout", service], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for attempt in range(5):
    result = subprocess.run(["launchctl", "bootstrap", f"gui/{os.getuid()}", str(plist_path)], capture_output=True)
    if result.returncode == 0:
        break
    if attempt == 4:
        raise SystemExit("Could not start the terminal service. Try enabling this Mac again.")
    time.sleep(1)
print("Terminal service enabled.")
