"""Read host aliases without running ssh -G, Match exec, or copying private keys."""
import fnmatch
import getpass
import glob
import os
from pathlib import Path
import re
import shlex

ALIAS = re.compile(r"[a-zA-Z0-9_][a-zA-Z0-9_.-]{0,79}")


def config_hosts(path=None):
    path = Path(path or Path.home() / ".ssh/config")
    lines = []
    visited = set()
    def read(file):
        file = Path(file).expanduser()
        if file in visited or len(visited) >= 64:
            return
        visited.add(file)
        try:
            text = file.read_text()[:1024 * 1024]
        except (OSError, UnicodeError):
            return
        for line in text.splitlines():
            try:
                fields = shlex.split(line, comments=True)
            except ValueError:
                continue
            if not fields:
                continue
            # OpenSSH permits both 'HostName value' and 'HostName=value'.
            key, separator, value = fields[0].partition("=")
            args = ([value] if separator and value else []) + fields[1:]
            if args and args[0] == "=":
                args = args[1:]
            if key.lower() == "include":
                for pattern in args:
                    expanded = os.path.expanduser(pattern)
                    if not os.path.isabs(expanded):
                        expanded = str(path.parent / expanded)
                    for included in sorted(glob.glob(expanded))[:64]:
                        read(included)
            else:
                lines.append((key.lower(), args))
    read(path)
    aliases = sorted({a for key, args in lines if key == "host" for a in args if ALIAS.fullmatch(a)}, key=str.casefold)
    results = []
    for alias in aliases[:100]:
        options = {}
        active = True
        for key, args in lines:
            if key == "host":
                active = any(fnmatch.fnmatchcase(alias, p) for p in args if not p.startswith("!")) and not any(fnmatch.fnmatchcase(alias, p[1:]) for p in args if p.startswith("!"))
            elif key == "match":
                active = False # Conditional values are resolved by OpenSSH only when connecting.
            elif active and args and key in ("hostname", "user", "port"):
                options.setdefault(key, args[0])
        try:
            port = int(options.get("port", "22"))
        except ValueError:
            port = 22
        results.append(dict(alias=alias, name=alias, hostname=options.get("hostname", alias).replace("%h", alias),
                            username=options.get("user", getpass.getuser()), port=port if 1 <= port <= 65535 else 22))
    return results
