"""Private development terminal gateway. Bind only to loopback or a Tailscale IP."""
import argparse
import asyncio
import contextlib
import fcntl
import hmac
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import struct
import sys
import termios
import uuid

from aiohttp import web, WSMsgType
from discovery import Discovery
from command_drafts import CommandDrafts
from pairing import Pairing
from ssh_config import config_hosts

PREFIX = "vibe-"


def safe_text(value, name, maximum=80):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise web.HTTPBadRequest(text=f"Invalid {name}")
    return value.strip()


def validate_host(body):
    name = safe_text(body.get("name"), "name")
    hostname = safe_text(body.get("hostname"), "hostname", 253)
    username = safe_text(body.get("username"), "username", 64)
    if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9.:-]*", hostname):
        raise web.HTTPBadRequest(text="Use a hostname or IP address")
    if not re.fullmatch(r"[a-zA-Z0-9_][a-zA-Z0-9_.-]*", username):
        raise web.HTTPBadRequest(text="Invalid SSH username")
    port = body.get("port", 22)
    if type(port) is not int or not 1 <= port <= 65535:
        raise web.HTTPBadRequest(text="Port must be between 1 and 65535")
    return dict(id=uuid.uuid4().hex, name=name, hostname=hostname, username=username, port=port, kind="ssh")


class Gateway:
    def __init__(self, directory, tmux=None, socket="vibe-mobile", local_command=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.tmux = tmux or shutil.which("tmux")
        if not self.tmux:
            raise RuntimeError("Install tmux before starting the gateway")
        self.socket = socket
        self.config = self.directory / "tmux.conf"
        self.config.write_text("set -g history-limit 10000\nset -g extended-keys on\nset -as terminal-features ',xterm-256color:RGB:extkeys'\n")
        self.local_command = local_command or ["/bin/zsh", "-l"]
        token_path = self.directory / "token"
        if not token_path.exists():
            with open(token_path, "x", opener=lambda p, f: os.open(p, f, 0o600)) as file:
                file.write(secrets.token_urlsafe(32))
        self.token = token_path.read_text().strip()
        if len(self.token) < 32:
            raise RuntimeError("Gateway token must contain at least 32 characters")
        self.host_file = self.directory / "hosts.json"
        self.hosts = json.loads(self.host_file.read_text()) if self.host_file.exists() else []
        self.clients = set()
        self.client_tokens = {}
        self.session_lock = asyncio.Lock()
        self.discovery = Discovery()
        self.command_drafts = CommandDrafts()
        self.pairing = Pairing(self.directory)

    async def run(self, *args, check=True):
        process = await asyncio.create_subprocess_exec(self.tmux, "-L", self.socket, "-f", str(self.config), *args,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            out, err = await asyncio.wait_for(process.communicate(), 10)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            raise web.HTTPGatewayTimeout(text="tmux did not respond")
        if check and process.returncode:
            raise web.HTTPBadRequest(text=err.decode(errors="replace").strip())
        return out.decode(errors="replace")

    def all_hosts(self):
        return [dict(id="mini", name=os.environ.get("VIBE_MACHINE_NAME", "Mac mini"), hostname=os.uname().nodename, username=os.environ.get("USER", "mcmurdo"),
                     port=22, kind="local")] + self.hosts

    async def list_hosts(self, request):
        return web.json_response(self.all_hosts())

    async def issue_pairing(self, request):
        return web.json_response(self.pairing.issue())

    async def redeem_pairing(self, request):
        return web.json_response(self.pairing.redeem(await request.json()))

    async def paired_devices(self, request):
        return web.json_response([dict(id=d["id"], name=d["name"]) for d in self.pairing.devices])

    async def revoke_device(self, request):
        self.pairing.revoke(request.match_info["device_id"])
        # Close existing transports too: a revoked credential must not retain shell access.
        await asyncio.gather(*(ws.close(code=1008, message=b"Device access changed") for ws in list(self.clients) if self.client_tokens.get(ws) != self.token and not self.pairing.accepts(self.client_tokens.get(ws, ""))))
        return web.json_response({"ok": True})

    async def importable_hosts(self, request):
        return web.json_response(config_hosts())

    async def import_hosts(self, request):
        aliases = (await request.json()).get("aliases")
        if not isinstance(aliases, list) or not all(isinstance(a, str) for a in aliases) or len(aliases) > 50:
            raise web.HTTPBadRequest(text="Choose up to 50 SSH hosts")
        available = {h["alias"]: h for h in config_hosts()}
        if any(alias not in available for alias in aliases):
            raise web.HTTPBadRequest(text="An SSH alias no longer exists. Refresh your hosts.")
        updated = list(self.hosts)
        for alias in dict.fromkeys(aliases):
            if any(h.get("alias") == alias for h in updated):
                continue
            host = dict(available[alias], id=uuid.uuid4().hex, kind="config")
            updated.append(host)
        if len(updated) > 50:
            raise web.HTTPConflict(text="Host limit reached")
        tmp = self.host_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(updated))
        tmp.chmod(0o600)
        tmp.replace(self.host_file)
        self.hosts = updated
        return web.json_response(self.all_hosts())

    async def discover_hosts(self, request):
        return web.json_response(await self.discovery.scan())

    async def add_host(self, request):
        host = validate_host(await request.json())
        if len(self.hosts) >= 50:
            raise web.HTTPConflict(text="Host limit reached")
        updated = self.hosts + [host]
        tmp = self.host_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(updated))
        tmp.chmod(0o600)
        tmp.replace(self.host_file)
        self.hosts = updated
        return web.json_response(host, status=201)

    async def delete_host(self, request):
        host_id = request.match_info["host_id"]
        async with self.session_lock:
            if not any(h["id"] == host_id for h in self.hosts):
                raise web.HTTPNotFound(text="Saved SSH host not found")
            if any(s["hostID"] == host_id for s in await self.sessions()):
                raise web.HTTPConflict(text="End this host's sessions before removing it")
            updated = [h for h in self.hosts if h["id"] != host_id]
            tmp = self.host_file.with_suffix(".tmp")
            tmp.write_text(json.dumps(updated))
            tmp.chmod(0o600)
            tmp.replace(self.host_file)
            self.hosts = updated
        return web.json_response({"ok": True})

    async def sessions(self):
        result = await self.run("list-sessions", "-F", "#{session_name}\t#{@vibe-title}\t#{@vibe-host}\t#{session_attached}", check=False)
        rows = []
        for line in result.splitlines():
            parts = line.split("\t")
            if len(parts) == 4 and re.fullmatch(r"vibe-[0-9a-f]{32}", parts[0]):
                rows.append(dict(id=parts[0], title=parts[1] or "Terminal", hostID=parts[2], attached=parts[3] != "0"))
        return rows

    async def list_sessions(self, request):
        return web.json_response(await self.sessions())

    async def create_session(self, request):
        body = await request.json()
        host = next((h for h in self.all_hosts() if h["id"] == body.get("hostID")), None)
        if not host:
            raise web.HTTPNotFound(text="Host not found")
        title = safe_text(body.get("title", host["name"]), "session title")
        provider = body.get("loginProvider")
        if request.path == "/v1/login-sessions" and provider is None:
            raise web.HTTPBadRequest(text="Choose Codex or Claude")
        if provider is not None and (provider not in ("codex", "claude") or host["kind"] != "local"):
            raise web.HTTPBadRequest(text="Choose Codex or Claude on the paired Mac")
        sid = PREFIX + uuid.uuid4().hex
        if host["kind"] == "local":
            command = self.local_command
        elif host["kind"] == "config":
            if host.get("alias") not in {h["alias"] for h in config_hosts()}:
                raise web.HTTPBadRequest(text="This SSH alias was removed from the Mac’s configuration.")
            command = ["/usr/bin/ssh", "-tt", "-o", "StrictHostKeyChecking=yes", "-o", "ServerAliveInterval=15", host["alias"]]
        else:
            command = ["/usr/bin/ssh", "-tt", "-o", "StrictHostKeyChecking=yes", "-o", "ServerAliveInterval=15",
                       "-o", "ServerAliveCountMax=3", "-p", str(host["port"]), "-l", host["username"], host["hostname"]]
        if provider is not None:
            # Fixed commands only; no caller-supplied shell text. Keep the result visible.
            login = "codex login --device-auth" if provider == "codex" else "claude auth login --claudeai"
            title = provider.title() + " sign in"
            command = ["/bin/zsh", "-lc", "unset ANTHROPIC_API_KEY ANTHROPIC_AUTH_TOKEN CLAUDE_CODE_OAUTH_TOKEN OPENAI_API_KEY; "
                       "export BROWSER=/usr/bin/false; " + login +
                       "; result=$?; if [ $result -eq 0 ]; then printf '\nSign-in completed. You can close this session.\n'; "
                       "else printf '\nSign-in did not complete. Close this session and try again.\n'; fi; "
                       "read -r '?Press Return to close.'"]
        async with self.session_lock:
            if not any(h["id"] == host["id"] for h in self.all_hosts()):
                raise web.HTTPNotFound(text="Host was removed")
            if len(await self.sessions()) >= 32:
                raise web.HTTPConflict(text="Close a terminal before creating another (32 session limit)")
            await self.run("source-file", str(self.config), check=False)
            await self.run("new-session", "-d", "-s", sid, "-x", "100", "-y", "30", *command)
            await self.run("set-option", "-t", sid, "mouse", "on")
            await self.run("set-option", "-t", sid, "status", "off")
            await self.run("set-option", "-t", sid, "@vibe-title", title)
            await self.run("set-option", "-t", sid, "@vibe-host", host["id"])
        return web.json_response(dict(id=sid, title=title, hostID=host["id"], attached=False), status=201)

    async def require_session(self, request):
        sid = request.match_info["sid"]
        if not re.fullmatch(r"vibe-[0-9a-f]{32}", sid) or not any(s["id"] == sid for s in await self.sessions()):
            raise web.HTTPNotFound(text="Session ended or no longer exists")
        return sid

    async def rename_session(self, request):
        sid = await self.require_session(request)
        title = safe_text((await request.json()).get("title"), "session title")
        await self.run("set-option", "-t", sid, "@vibe-title", title)
        session = next((s for s in await self.sessions() if s["id"] == sid), None)
        if not session:
            raise web.HTTPNotFound(text="Session ended")
        return web.json_response(session)

    async def delete_session(self, request):
        sid = await self.require_session(request)
        await self.run("kill-session", "-t", "=" + sid)
        return web.json_response({"ok": True})

    async def draft_context(self, request):
        sid = await self.require_session(request)
        session = next(s for s in await self.sessions() if s["id"] == sid)
        host = next((h for h in self.all_hosts() if h["id"] == session["hostID"]), None)
        context = {"session": session["title"], "scope": "Snapshot; user may edit before sending"}
        if host:
            context.update(host=host["name"], protocol="local" if host["kind"] == "local" else "SSH")
            if host["kind"] == "local":
                pane = await self.run("display-message", "-p", "-t", "=" + sid + ":",
                                      "#{pane_current_command}\n#{pane_current_path}")
                command, _, directory = pane.rstrip("\n").partition("\n")
                context["foreground_program_on_gateway"] = command
                if command in ("zsh", "bash", "sh", "fish", "dash", "ksh"):
                    context.update(os=os.uname().sysname, shell=command, working_directory=directory)
                else:
                    context["target_details"] = "Unknown: foreground program is not a recognized local shell; it may be an SSH client, container, or interactive application."
            else:
                context["target_details"] = "Remote OS, shell, current directory and current SSH connection state are unknown. Supply them below if relevant."
        return web.json_response({"text": json.dumps(context, ensure_ascii=False, indent=2)[:6000]})

    async def history(self, request):
        sid = await self.require_session(request)
        text = await self.run("capture-pane", "-p", "-J", "-S", "-10000", "-t", "=" + sid + ":")
        # Keep the response bounded even when unusually wide lines fill history.
        return web.json_response({"text": text[-1024 * 1024:]})

    async def terminal(self, request):
        sid = await self.require_session(request)
        if len(self.clients) >= 16:
            raise web.HTTPServiceUnavailable(text="Too many terminal connections")
        ws = web.WebSocketResponse(heartbeat=20, max_msg_size=65536)
        await ws.prepare(request)
        self.clients.add(ws)
        self.client_tokens[ws] = request.headers.get("Authorization", "").removeprefix("Bearer ")
        master, slave = os.openpty()
        os.set_blocking(master, False)
        environment = dict(os.environ, TERM="xterm-256color", COLORTERM="truecolor")
        process = None
        output_task = None
        try:
            process = await asyncio.create_subprocess_exec(sys.executable, str(Path(__file__).with_name("pty_exec.py")),
                str(slave), self.tmux, "-L", self.socket, "attach-session", "-t", "=" + sid,
                pass_fds=(slave,), env=environment)
            os.close(slave)
            slave = -1

            async def output():
                try:
                    while True:
                        await ready(master, write=False)
                        try:
                            data = os.read(master, 16384)
                        except BlockingIOError:
                            continue
                        if not data:
                            break
                        await ws.send_bytes(data)
                except (OSError, ConnectionError):
                    pass
                finally:
                    await ws.close()

            output_task = asyncio.create_task(output())
            async for message in ws:
                if message.type == WSMsgType.BINARY:
                    data = memoryview(message.data)
                    while data:
                        try:
                            count = os.write(master, data)
                            data = data[count:]
                        except BlockingIOError:
                            await ready(master, write=True)
                elif message.type == WSMsgType.TEXT:
                    try:
                        size = json.loads(message.data)
                        cols, rows = size["cols"], size["rows"]
                        if type(cols) is not int or type(rows) is not int or not 2 <= cols <= 500 or not 2 <= rows <= 300:
                            raise ValueError("Invalid dimensions")
                        fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
                    except (ValueError, KeyError, TypeError):
                        await ws.close(code=1008, message=b"Invalid terminal size")
                elif message.type == WSMsgType.ERROR:
                    break
        finally:
            self.clients.discard(ws)
            self.client_tokens.pop(ws, None)
            if output_task:
                output_task.cancel()
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await output_task
            os.close(master)
            if slave >= 0:
                os.close(slave)
            if process:
                # Only detach the transport client. The tmux session stays alive.
                with contextlib.suppress(ProcessLookupError):
                    process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), 3)
                except asyncio.TimeoutError:
                    with contextlib.suppress(ProcessLookupError):
                        process.kill()
                    await process.wait()
        return ws

    async def shutdown(self, app):
        await asyncio.gather(*(ws.close(code=1001, message=b"Gateway restarting") for ws in list(self.clients)))


def ready(fd, write):
    loop = asyncio.get_running_loop()
    future = loop.create_future()
    add = loop.add_writer if write else loop.add_reader
    remove = loop.remove_writer if write else loop.remove_reader
    def available():
        remove(fd)
        if not future.done():
            future.set_result(None)
    add(fd, available)
    async def wait():
        try:
            await future
        finally:
            remove(fd)
    return wait()


def create_app(gateway):
    @web.middleware
    async def authorize(request, handler):
        # Native client only: do not let browser pages drive a shell on this machine.
        if request.headers.get("Origin"):
            raise web.HTTPForbidden(text="Browser origins are not supported")
        expected = "Bearer " + gateway.token
        authorization = request.headers.get("Authorization", "")
        admin = hmac.compare_digest(authorization.encode(), expected.encode())
        redeem = request.path == "/v1/pairings/redeem" and request.method == "POST"
        administrative = request.path == "/v1/pairings" or request.path.startswith("/v1/devices")
        device = authorization.removeprefix("Bearer ") if authorization.startswith("Bearer ") else ""
        if (administrative and not admin) or (not redeem and not admin and not gateway.pairing.accepts(device)):
            raise web.HTTPUnauthorized(text="Enter the gateway access token in Terminal settings")
        try:
            return await handler(request)
        except (json.JSONDecodeError, AttributeError):
            raise web.HTTPBadRequest(text="Expected a JSON object")
    app = web.Application(middlewares=[authorize], client_max_size=65536)
    app.add_routes([
        web.post("/v1/pairings", gateway.issue_pairing), web.post("/v1/pairings/redeem", gateway.redeem_pairing),
        web.get("/v1/devices", gateway.paired_devices), web.delete("/v1/devices/{device_id}", gateway.revoke_device),
        web.get("/v1/importable-hosts", gateway.importable_hosts), web.post("/v1/import-hosts", gateway.import_hosts),
        web.get("/v1/discovery", gateway.discover_hosts),
        web.post("/v1/command-drafts", gateway.command_drafts.generate),
        web.get("/v1/hosts", gateway.list_hosts), web.post("/v1/hosts", gateway.add_host),
        web.delete("/v1/hosts/{host_id}", gateway.delete_host),
        web.post("/v1/login-sessions", gateway.create_session),
        web.get("/v1/sessions", gateway.list_sessions), web.post("/v1/sessions", gateway.create_session),
        web.delete("/v1/sessions/{sid}", gateway.delete_session),
        web.patch("/v1/sessions/{sid}", gateway.rename_session),
        web.get("/v1/sessions/{sid}/terminal", gateway.terminal),
        web.get("/v1/sessions/{sid}/history", gateway.history),
        web.get("/v1/sessions/{sid}/draft-context", gateway.draft_context),
    ])
    app.on_shutdown.append(gateway.shutdown)
    return app


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9843)
    parser.add_argument("--state", type=Path, default=Path.home() / ".vibe-terminal")
    args = parser.parse_args()
    ip = ipaddress.ip_address(args.bind)
    if not (ip.is_loopback or ip in ipaddress.ip_network("100.64.0.0/10")):
        parser.error("Bind must be loopback or a Tailscale IPv4 address")
    gateway = Gateway(args.state)
    web.run_app(create_app(gateway), host=args.bind, port=args.port, access_log=None)
