"""Fresh process establishes a controlling terminal before exec (no fork in asyncio)."""
import os
import sys

os.login_tty(int(sys.argv[1]))
os.execv(sys.argv[2], sys.argv[2:])
