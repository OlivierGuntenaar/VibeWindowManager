"""Short-lived, single-use pairing grants and revocable device credentials."""
import hashlib
import json
import secrets
import time
from pathlib import Path

from aiohttp import web


class Pairing:
    def __init__(self, directory):
        self.path = Path(directory) / "devices.json"
        self.devices = json.loads(self.path.read_text()) if self.path.exists() else []
        self.grants = {}

    def accepts(self, token):
        digest = hashlib.sha256(token.encode()).hexdigest()
        return any(secrets.compare_digest(digest, d["digest"]) for d in self.devices)

    def save(self):
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.devices))
        temporary.chmod(0o600)
        temporary.replace(self.path)

    def issue(self):
        # One currently displayed QR code. Regenerating invalidates the previous one.
        code = secrets.token_urlsafe(32)
        self.grants = {code: time.monotonic() + 120}
        return {"code": code, "expiresIn": 120}

    def redeem(self, body):
        code = body.get("code")
        if not isinstance(code, str) or len(code) > 100:
            raise web.HTTPBadRequest(text="Invalid pairing code")
        expiration = self.grants.pop(code, 0)
        if expiration < time.monotonic():
            raise web.HTTPUnauthorized(text="This pairing code expired or was already used. Generate another on your Mac.")
        name = body.get("name", "iPhone")
        if not isinstance(name, str) or not name.strip() or len(name) > 80 or any(ord(c) < 32 for c in name):
            raise web.HTTPBadRequest(text="Invalid device name")
        if len(self.devices) >= 32:
            raise web.HTTPConflict(text="Remove a paired device on your Mac before adding another.")
        token = secrets.token_urlsafe(32)
        device = dict(id=secrets.token_hex(16), name=name.strip(), digest=hashlib.sha256(token.encode()).hexdigest())
        self.devices.append(device)
        self.save()
        return dict(token=token, deviceID=device["id"])

    def revoke(self, device_id):
        updated = [d for d in self.devices if d["id"] != device_id]
        if len(updated) == len(self.devices):
            raise web.HTTPNotFound(text="Device not found")
        self.devices = updated
        self.save()
