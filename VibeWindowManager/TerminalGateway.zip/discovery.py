"""Discover only peers returned by the local Tailscale client; never scan a subnet."""
import asyncio
import contextlib
import ipaddress
import json
import shutil
import time
from pathlib import Path

from aiohttp import web

TAILNET_V4 = ipaddress.ip_network("100.64.0.0/10")
TAILNET_V6 = ipaddress.ip_network("fd7a:115c:a1e0::/48")


def peer_devices(status):
    devices = []
    seen = set()
    for peer in (status.get("Peer") or {}).values():
        addresses = []
        for value in peer.get("TailscaleIPs") or []:
            try:
                ip = ipaddress.ip_address(value)
                if ip in (TAILNET_V4 if ip.version == 4 else TAILNET_V6):
                    addresses.append(str(ip))
            except ValueError:
                continue
        if not addresses:
            continue
        address = next((ip for ip in addresses if ":" not in ip), addresses[0])
        if address in seen:
            continue
        seen.add(address)
        dns = str(peer.get("DNSName") or "").rstrip(".")[:253]
        name = dns.split(".")[0] if dns else str(peer.get("HostName") or address)
        name = "".join(c for c in name if c.isprintable()).strip()[:80] or address
        devices.append(dict(id=address, name=name, hostname=address, dnsName=dns,
                            os=str(peer.get("OS") or "")[:40], online=peer.get("Online") is True,
                            port=22))
    # Bound work and prefer online devices when a large tailnet exceeds the limit.
    devices.sort(key=lambda d: (not d["online"], d["name"].casefold(), d["id"]))
    return devices[:64], len(devices) > 64


async def read_status():
    executable = shutil.which("tailscale")
    if executable is None:
        app = Path("/Applications/Tailscale.app/Contents/MacOS/Tailscale")
        if app.is_file():
            executable = str(app)
    if executable is None:
        raise web.HTTPServiceUnavailable(text="Install and connect Tailscale on your Mac mini to discover hosts.")
    process = await asyncio.create_subprocess_exec(executable, "status", "--json",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
    try:
        output, _ = await asyncio.wait_for(process.communicate(), 4)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        with contextlib.suppress(ProcessLookupError):
            process.kill()
        await process.wait()
        raise
    if process.returncode:
        raise web.HTTPServiceUnavailable(text="Tailscale status is unavailable on your Mac mini.")
    try:
        status = json.loads(output)
    except (ValueError, UnicodeDecodeError):
        raise web.HTTPServiceUnavailable(text="Tailscale returned an unreadable device list.")
    if not isinstance(status, dict) or status.get("BackendState") != "Running":
        raise web.HTTPServiceUnavailable(text="Connect Tailscale on your Mac mini, then refresh discovery.")
    return status


async def probe_ssh(address, port=22):
    """Read the server identification only. No login or host-key acceptance occurs."""
    writer = None
    try:
        async with asyncio.timeout(2):
            reader, writer = await asyncio.open_connection(address, port, limit=4096)
            for _ in range(8):
                line = await reader.readline()
                if line.startswith((b"SSH-2.0-", b"SSH-1.99-")):
                    return True
                if not line:
                    break
    except (OSError, TimeoutError, ValueError):
        pass
    finally:
        if writer:
            writer.close()
            with contextlib.suppress(OSError, TimeoutError):
                await asyncio.wait_for(writer.wait_closed(), 0.25)
    return False


class Discovery:
    def __init__(self):
        self.lock = asyncio.Lock()
        self.cached = None
        self.checked = 0

    async def scan(self):
        async with self.lock:
            if self.cached is not None and time.monotonic() - self.checked < 30:
                return self.cached
            try:
                status = await read_status()
            except asyncio.TimeoutError:
                raise web.HTTPServiceUnavailable(text="Tailscale took too long to respond. Try again.")
            devices, truncated = peer_devices(status)
            semaphore = asyncio.Semaphore(16)
            async def check(device):
                async with semaphore:
                    device["sshStatus"] = ("reachable" if await probe_ssh(device["hostname"]) else "notDetected") if device["online"] else "offline"
                return device
            results = await asyncio.gather(*(check(device) for device in devices))
            results.sort(key=lambda d: ({"reachable": 0, "notDetected": 1, "offline": 2}[d["sshStatus"]], d["name"].casefold()))
            self.cached = dict(devices=results, truncated=truncated)
            self.checked = time.monotonic()
            return self.cached
